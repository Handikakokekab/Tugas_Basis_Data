<?php
include 'koneksi.php';

$type = $_GET['type']; // 'pemesanan' atau 'kontak'
$id = $_GET['id'];

if($type == 'pemesanan'){
    mysqli_query($conn, "DELETE FROM pemesanan WHERE id='$id'");
} elseif($type == 'kontak'){
    mysqli_query($conn, "DELETE FROM kontak WHERE id='$id'");
}

header("Location: admin.php");
exit;
?>
