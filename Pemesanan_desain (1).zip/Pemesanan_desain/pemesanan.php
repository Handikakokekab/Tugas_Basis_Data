<?php 
$currentPage = 'pemesanan'; 
include 'koneksi.php';

$message = "";

if(isset($_POST['submit'])){
    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $jenis = mysqli_real_escape_string($conn, $_POST['jenis']);
    $deskripsi = mysqli_real_escape_string($conn, $_POST['deskripsi']);
    $tanggal = $_POST['tanggal'];

    $insert = mysqli_query($conn, "INSERT INTO pemesanan (nama,email,jenis,deskripsi,tanggal) VALUES ('$nama','$email','$jenis','$deskripsi','$tanggal')");
    
    if($insert){
        $message = "Pesanan berhasil dikirim!";
    } else {
        $message = "Terjadi kesalahan, coba lagi.";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pemesanan Jasa Desain Grafis</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
<style>
body {
    font-family: 'Poppins', sans-serif;
    background-color: #f8f9fa;
}
.card {
    border-radius: 15px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    padding: 25px;
    margin-bottom: 30px;
    max-width: 700px;
    margin-left: auto;
    margin-right: auto;
}
h3 {
    color: #0d6efd;
}
.form-control:focus {
    border-color: #0d6efd;
    box-shadow: 0 0 0 0.2rem rgba(13,110,253,.25);
}
.btn-primary {
    background-color: #0d6efd;
    border: none;
    font-weight: 600;
}
.btn-primary:hover {
    background-color: #0b5ed7;
}
.alert {
    border-radius: 10px;
    font-weight: 500;
}
</style>
</head>
<body>

<?php include 'navbar.php'; ?>

<div class="container mt-5 mb-5">
    <div class="card">
      <div class="card-body">
        <h3 class="text-center mb-4">Form Pemesanan Jasa Desain Grafis</h3>

        <?php if($message != ""): ?>
            <div class="alert alert-success text-center"><?php echo $message; ?></div>
        <?php endif; ?>

        <form action="" method="POST">
          <div class="mb-3">
            <label class="form-label">Nama Lengkap</label>
            <input type="text" class="form-control" name="nama" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Email</label>
            <input type="email" class="form-control" name="email" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Jenis Desain</label>
            <select class="form-select" name="jenis" required>
              <option value="">-- Pilih Jenis Desain --</option>
              <option value="logo">Logo</option>
              <option value="poster">Poster</option>
              <option value="banner">Banner</option>
            </select>
          </div>
          <div class="mb-3">
            <label class="form-label">Deskripsi</label>
            <textarea class="form-control" name="deskripsi" rows="4"></textarea>
          </div>
          <div class="mb-3">
            <label class="form-label">Tanggal Pemesanan</label>
            <input type="date" class="form-control" name="tanggal" required>
          </div>
          <div class="d-grid">
            <button type="submit" name="submit" class="btn btn-primary btn-lg">Kirim Pesanan</button>
          </div>
        </form>
      </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
