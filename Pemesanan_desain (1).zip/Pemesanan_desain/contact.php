<?php
$currentPage = 'kontak';
include 'koneksi.php';

$msg = "";

if(isset($_POST['submit'])){
    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $pesan = mysqli_real_escape_string($conn, $_POST['pesan']);

    $insert = mysqli_query($conn, "INSERT INTO kontak (nama,email,pesan) VALUES ('$nama','$email','$pesan')");
    
    if($insert){
        $msg = "Pesan berhasil dikirim!";
    } else {
        $msg = "Terjadi kesalahan, coba lagi.";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Kontak Kami - DesainKu</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
<style>
body {
    font-family: 'Poppins', sans-serif;
    background-color: #f8f9fa;
}
.card {
    border-radius: 15px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    padding: 25px;
    margin-bottom: 20px;
}
h3 {
    color: #0d6efd;
}
.form-control:focus {
    border-color: #0d6efd;
    box-shadow: 0 0 0 0.2rem rgba(13,110,253,.25);
}
.btn-primary {
    background-color: #0d6efd;
    border: none;
    font-weight: 600;
}
.btn-primary:hover {
    background-color: #0b5ed7;
}
.alert {
    border-radius: 10px;
    font-weight: 500;
}
@media (max-width: 768px) {
    .row {
        flex-direction: column;
    }
}
</style>
</head>
<body>

<?php include 'navbar.php'; ?>

<div class="container mt-5 mb-5">
    <div class="row g-4">
        <!-- Form Kontak -->
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h3 class="mb-4 text-center">Hubungi Kami</h3>

                    <?php if($msg != ""): ?>
                        <div class="alert alert-success text-center"><?php echo $msg; ?></div>
                    <?php endif; ?>

                    <form action="" method="POST">
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Nama Lengkap</label>
                            <input type="text" class="form-control" name="nama" placeholder="Masukkan nama lengkap" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Email</label>
                            <input type="email" class="form-control" name="email" placeholder="Masukkan email" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Pesan</label>
                            <textarea class="form-control" name="pesan" rows="5" placeholder="Tulis pesan Anda" required></textarea>
                        </div>
                        <div class="d-grid">
                            <button type="submit" name="submit" class="btn btn-primary btn-lg">Kirim Pesan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Info Kontak -->
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h3 class="mb-4 text-center">Informasi Kontak</h3>
                    <p><strong>Email:</strong> info@desainku.com</p>
                    <p><strong>Telepon:</strong> +62 812 3456 7890</p>
                    <p><strong>Alamat:</strong> Jl. Kreatif No. 12, Jakarta, Indonesia</p>
                    <hr>
                    <h5>Jam Kerja</h5>
                    <p>Senin - Jumat: 09.00 - 18.00 WIB</p>
                    <p>Sabtu: 09.00 - 15.00 WIB</p>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
