<?php $currentPage = 'tentang'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tentang Kami - DesainKu</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background-color: #f8f9fa;
    }
    .card {
      border-radius: 15px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.1);
      padding: 30px;
    }
    h2, h4 {
      color: #0d6efd;
    }
    img:hover {
      transform: scale(1.05);
      transition: 0.3s;
    }
    ul li {
      margin-bottom: 8px;
      font-size: 1rem;
    }
    .lead {
      font-size: 1.1rem;
    }
    @media (max-width: 768px) {
      .row.align-items-center {
        flex-direction: column;
        text-align: center;
      }
      .row.align-items-center .col-md-6 {
        margin-bottom: 20px;
      }
    }
  </style>
</head>
<body>

  <?php include 'navbar.php'; ?>

  <div class="container mt-5 mb-5">
    <div class="card mx-auto" style="max-width:900px;">
      <div class="card-body">
        <h2 class="text-center mb-4">Tentang Kami</h2>
        <p class="lead text-center">
          <strong>DesainKu</strong> adalah platform layanan desain grafis yang membantu individu dan bisnis 
          untuk mendapatkan desain profesional dengan mudah, cepat, dan terjangkau.
        </p>

        <hr>

        <div class="row align-items-center mt-4">
          <div class="col-md-6 text-center">
            <img src="https://cdn-icons-png.flaticon.com/512/6195/6195699.png" 
                 class="img-fluid rounded shadow-sm" alt="DesainKu" style="max-width: 300px;">
          </div>
          <div class="col-md-6">
            <h4>Misi Kami</h4>
            <p>
              Kami berkomitmen untuk memberikan hasil desain yang memuaskan dengan memperhatikan detail, 
              kreativitas, dan kebutuhan klien.  
              Tim kami terdiri dari desainer profesional yang siap membantu menciptakan identitas visual terbaik untuk Anda.
            </p>
          </div>
        </div>

        <div class="mt-4">
          <h4>Kenapa Memilih Kami?</h4>
          <ul>
            <li>💡 Ide kreatif dan unik untuk setiap klien</li>
            <li>⚡ Proses cepat dan komunikasi mudah</li>
            <li>🎨 Desainer profesional dan berpengalaman</li>
            <li>💰 Harga terjangkau dengan kualitas tinggi</li>
          </ul>
        </div>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
