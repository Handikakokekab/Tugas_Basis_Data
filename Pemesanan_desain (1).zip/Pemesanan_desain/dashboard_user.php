<?php
session_start();
include 'koneksi.php';

// Pastikan user sudah login
if(!isset($_SESSION['username']) || $_SESSION['role'] != 'user'){
    header("Location: login.php");
    exit;
}

$username = $_SESSION['username'];

// Ambil data user
$user_query = mysqli_query($conn, "SELECT * FROM users WHERE username='$username'");
$user = mysqli_fetch_assoc($user_query);

// Ambil pesanan user berdasarkan email
$pemesanan_query = mysqli_query($conn, "SELECT * FROM pemesanan WHERE email='{$user['email']}' ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard Pelanggan - DesainKu</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
<style>
body { font-family: 'Poppins', sans-serif; background-color: #f8f9fa; }
.card { border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); padding: 25px; margin-bottom: 20px; }
h3 { color: #0d6efd; }
.status-badge { padding: 5px 10px; border-radius: 12px; font-weight: 600; }
.status-proses { background-color: #ffc107; color: #000; }
.status-selesai { background-color: #198754; color: #fff; }
.status-belum { background-color: #6c757d; color: #fff; }
</style>
</head>
<body>

<?php include 'navbar.php'; ?>

<div class="container mt-5">
    <h3 class="mb-4">Hi, <?php echo $user['username']; ?> 👋</h3>

    <div class="card">
        <div class="card-body">
            <h4 class="mb-3">Pesanan Anda</h4>
            <?php if(mysqli_num_rows($pemesanan_query) > 0): ?>
            <table class="table table-bordered table-striped">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Jenis</th>
                        <th>Deskripsi</th>
                        <th>Tanggal</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                <?php while($row = mysqli_fetch_assoc($pemesanan_query)): ?>
                    <?php
                        $status = isset($row['status']) ? $row['status'] : 'Belum Diproses';
                        $status_class = 'status-belum';
                        if($status == 'Sedang Diproses') $status_class = 'status-proses';
                        if($status == 'Selesai') $status_class = 'status-selesai';
                    ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['jenis']; ?></td>
                        <td><?php echo $row['deskripsi']; ?></td>
                        <td><?php echo $row['tanggal']; ?></td>
                        <td><span class="status-badge <?php echo $status_class; ?>"><?php echo $status; ?></span></td>
                    </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
            <?php else: ?>
                <p>Anda belum melakukan pemesanan.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
