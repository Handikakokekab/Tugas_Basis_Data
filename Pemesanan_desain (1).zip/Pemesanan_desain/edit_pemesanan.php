<?php
session_start();
include 'koneksi.php';

// Proteksi admin
if(!isset($_SESSION['username']) || $_SESSION['role'] != 'admin'){
    header("Location: login.php");
    exit;
}

$id = $_GET['id'] ?? null;
if(!$id){
    header("Location: admin.php");
    exit;
}

// Ambil data pemesanan
$data = mysqli_query($conn, "SELECT * FROM pemesanan WHERE id='$id'");
$row = mysqli_fetch_assoc($data);

// Update data jika form disubmit
if(isset($_POST['update'])){
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $jenis = $_POST['jenis'];
    $deskripsi = $_POST['deskripsi'];
    $tanggal = $_POST['tanggal'];

    mysqli_query($conn, "UPDATE pemesanan SET 
        nama='$nama', email='$email', jenis='$jenis', deskripsi='$deskripsi', tanggal='$tanggal' 
        WHERE id='$id'");

    header("Location: admin.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Edit Pemesanan</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2 class="mb-4">Edit Pemesanan ID: <?php echo $row['id']; ?></h2>
    <form method="POST">
        <div class="mb-3">
            <label>Nama Lengkap</label>
            <input type="text" name="nama" class="form-control" value="<?php echo $row['nama']; ?>" required>
        </div>
        <div class="mb-3">
            <label>Email</label>
            <input type="email" name="email" class="form-control" value="<?php echo $row['email']; ?>" required>
        </div>
        <div class="mb-3">
            <label>Jenis Desain</label>
            <select name="jenis" class="form-select" required>
                <option value="logo" <?php if($row['jenis']=='logo') echo 'selected'; ?>>Logo</option>
                <option value="poster" <?php if($row['jenis']=='poster') echo 'selected'; ?>>Poster</option>
                <option value="banner" <?php if($row['jenis']=='banner') echo 'selected'; ?>>Banner</option>
            </select>
        </div>
        <div class="mb-3">
            <label>Deskripsi</label>
            <textarea name="deskripsi" class="form-control" rows="4"><?php echo $row['deskripsi']; ?></textarea>
        </div>
        <div class="mb-3">
            <label>Tanggal Pemesanan</label>
            <input type="date" name="tanggal" class="form-control" value="<?php echo $row['tanggal']; ?>" required>
        </div>
        <button type="submit" name="update" class="btn btn-primary">Simpan Perubahan</button>
        <a href="admin.php" class="btn btn-secondary">Kembali</a>
    </form>
</div>
</body>
</html>
