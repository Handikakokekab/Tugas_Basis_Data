<?php
session_start();
include 'koneksi.php';

// Proteksi halaman admin
if(!isset($_SESSION['username']) || $_SESSION['role'] != 'admin'){
    header("Location: login.php");
    exit;
}

// Hitung pemesanan baru
$newOrdersQuery = mysqli_query($conn, "SELECT COUNT(*) AS total FROM pemesanan WHERE is_read = 0");
$newOrders = mysqli_fetch_assoc($newOrdersQuery)['total'];

// Hitung pesan kontak baru (belum dibalas)
$newContactsQuery = mysqli_query($conn, "SELECT COUNT(*) AS total FROM kontak WHERE balasan IS NULL OR balasan=''");
$newContacts = mysqli_fetch_assoc($newContactsQuery)['total'];

// Tandai semua pemesanan baru sebagai sudah dibaca
mysqli_query($conn, "UPDATE pemesanan SET is_read = 1 WHERE is_read = 0");
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard Admin - DesainKu</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand" href="#">DesainKu Admin</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <span class="nav-link text-light">Halo, <?php echo $_SESSION['username']; ?></span>
        </li>
        <li class="nav-item">
          <a class="nav-link btn btn-outline-light btn-sm ms-2" href="admin.php">
            Pemesanan Baru
            <?php if($newOrders > 0): ?>
              <span class="badge bg-danger"><?php echo $newOrders; ?></span>
            <?php endif; ?>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link btn btn-outline-light btn-sm ms-2" href="admin.php#kontak">
            Pesan Baru
            <?php if($newContacts > 0): ?>
              <span class="badge bg-danger"><?php echo $newContacts; ?></span>
            <?php endif; ?>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link btn btn-outline-light btn-sm ms-2" href="logout.php">Logout</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<div class="container mt-5">
  <h2 class="mb-4 text-center">Dashboard Admin - DesainKu</h2>

  <!-- Tabel Pemesanan -->
  <h4>Pemesanan</h4>
  <table class="table table-bordered table-striped mb-5">
    <thead class="table-dark">
      <tr>
        <th>ID</th>
        <th>Nama</th>
        <th>Email</th>
        <th>Jenis</th>
        <th>Deskripsi</th>
        <th>Tanggal</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $pemesanan = mysqli_query($conn, "SELECT * FROM pemesanan ORDER BY created_at DESC");
      if(mysqli_num_rows($pemesanan) > 0){
        while($row = mysqli_fetch_assoc($pemesanan)):
      ?>
      <tr>
        <td><?php echo $row['id']; ?></td>
        <td><?php echo $row['nama']; ?></td>
        <td><?php echo $row['email']; ?></td>
        <td><?php echo $row['jenis']; ?></td>
        <td><?php echo $row['deskripsi']; ?></td>
        <td><?php echo $row['tanggal']; ?></td>
        <td>
          <a href="edit_pemesanan.php?id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
          <a href="hapus.php?type=pemesanan&id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</a>
        </td>
      </tr>
      <?php 
        endwhile; 
      } else {
        echo '<tr><td colspan="7" class="text-center">Belum ada data pemesanan</td></tr>';
      }
      ?>
    </tbody>
  </table>

  <!-- Tabel Kontak -->
  <h4 id="kontak">Kontak</h4>
  <table class="table table-bordered table-striped">
    <thead class="table-dark">
      <tr>
        <th>ID</th>
        <th>Nama</th>
        <th>Email</th>
        <th>Pesan</th>
        <th>Balasan</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $kontak = mysqli_query($conn, "SELECT * FROM kontak ORDER BY created_at DESC");
      if(mysqli_num_rows($kontak) > 0){
        while($row = mysqli_fetch_assoc($kontak)):
      ?>
      <tr>
        <td><?php echo $row['id']; ?></td>
        <td><?php echo $row['nama']; ?></td>
        <td><?php echo $row['email']; ?></td>
        <td><?php echo $row['pesan']; ?></td>
        <td><?php echo $row['balasan'] ?? '-'; ?></td>
        <td>
          <a href="balas_kontak.php?id=<?php echo $row['id']; ?>" class="btn btn-success btn-sm">Balas</a>
          <a href="hapus.php?type=kontak&id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</a>
        </td>
      </tr>
      <?php 
        endwhile; 
      } else {
        echo '<tr><td colspan="6" class="text-center">Belum ada pesan masuk</td></tr>';
      }
      ?>
    </tbody>
  </table>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
