<?php
include 'koneksi.php';
$message = "";

if(isset($_POST['register'])){
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email    = mysqli_real_escape_string($conn, $_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $cek = mysqli_query($conn, "SELECT * FROM users WHERE username='$username' OR email='$email'");
    if(mysqli_num_rows($cek) > 0){
        $message = "Username atau Email sudah terdaftar!";
    } else {
        mysqli_query($conn, "INSERT INTO users (username,email,password) VALUES ('$username','$email','$password')");
        header("Location: login.php");
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Register - DesainKu</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
  <div class="card mx-auto" style="max-width: 500px;">
    <div class="card-body">
      <h3 class="text-center mb-4">Register</h3>
      <?php if($message != "") { echo '<div class="alert alert-danger">'.$message.'</div>'; } ?>
      <form method="POST">
        <div class="mb-3">
          <label class="form-label">Username</label>
          <input type="text" name="username" class="form-control" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Email</label>
          <input type="email" name="email" class="form-control" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Password</label>
          <input type="password" name="password" class="form-control" required>
        </div>
        <div class="d-grid">
          <button type="submit" name="register" class="btn btn-primary">Register</button>
        </div>
      </form>
      <p class="mt-3 text-center">Sudah punya akun? <a href="login.php">Login</a></p>
    </div>
  </div>
</div>
</body>
</html>
