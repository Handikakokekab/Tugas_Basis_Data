<?php $currentPage = 'home'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>DesainKu - Jasa Desain Grafis Profesional</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .hero {
      background: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)),
                  url('https://images.unsplash.com/photo-1587614382346-4ec70e388b28?auto=format&fit=crop&w=1600&q=80') center/cover;
      height: 90vh;
      color: white;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      text-align: center;
    }
    .hero h1 {
      font-size: 3rem;
      font-weight: bold;
    }
    .hero p {
      font-size: 1.2rem;
      margin-top: 10px;
    }
  </style>
</head>
<body>

  <?php include 'navbar.php'; ?>

  <!-- Hero Section -->
  <section class="hero">
    <div class="container">
      <h1>Selamat Datang di <span class="text-warning">DesainKu</span></h1>
      <p>Layanan desain grafis profesional untuk kebutuhan personal dan bisnis Anda.</p>
      <a href="pemesanan.php" class="btn btn-warning btn-lg mt-3">Pesan Sekarang</a>
    </div>
  </section>

  <!-- Layanan Section -->
  <section class="py-5">
    <div class="container">
      <h2 class="text-center mb-5">Layanan Kami</h2>
      <div class="row g-4">
        <div class="col-md-4">
          <div class="card shadow-sm h-100">
            <div class="card-body text-center">
              <img src="https://cdn-icons-png.flaticon.com/512/1048/1048953.png" width="80" alt="Logo">
              <h5 class="mt-3">Desain Logo</h5>
              <p>Buat identitas merek Anda menonjol dengan logo profesional dan berkarakter.</p>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div class="card shadow-sm h-100">
            <div class="card-body text-center">
              <img src="https://cdn-icons-png.flaticon.com/512/2731/2731767.png" width="80" alt="Poster">
              <h5 class="mt-3">Desain Poster</h5>
              <p>Poster menarik dan informatif untuk promosi acara, bisnis, atau kampanye sosial.</p>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div class="card shadow-sm h-100">
            <div class="card-body text-center">
              <img src="https://cdn-icons-png.flaticon.com/512/1160/1160058.png" width="80" alt="Feed IG">
              <h5 class="mt-3">Desain Sosial Media</h5>
              <p>Tingkatkan engagement dengan desain feed Instagram dan konten kreatif.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Testimoni Section -->
  <section class="bg-light py-5">
    <div class="container">
      <h2 class="text-center mb-5">Apa Kata Klien Kami</h2>
      <div class="row">
        <div class="col-md-4">
          <div class="card shadow-sm border-0">
            <div class="card-body text-center">
              <p>"DesainKu membantu brand saya terlihat lebih profesional. Hasilnya cepat dan keren!"</p>
              <h6>- Andi Pratama</h6>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card shadow-sm border-0">
            <div class="card-body text-center">
              <p>"Harga bersahabat tapi kualitas tinggi. Sangat direkomendasikan!"</p>
              <h6>- Siti Nurhaliza</h6>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card shadow-sm border-0">
            <div class="card-body text-center">
              <p>"Pelayanan cepat dan desainer komunikatif. Pasti pesan lagi!"</p>
              <h6>- Dimas Rahman</h6>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
