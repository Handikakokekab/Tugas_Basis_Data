<?php
if(session_status() === PHP_SESSION_NONE){
    session_start();
}

$role = isset($_SESSION['role']) ? $_SESSION['role'] : '';
$username = isset($_SESSION['username']) ? $_SESSION['username'] : '';
?>

<nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #343a40;">
  <div class="container">
    <!-- Hi, username -->
    <?php if($role == 'user'): ?>
        <a class="navbar-brand text-warning me-4" href="#">Hi, <?php echo $username; ?> 👋</a>
    <?php endif; ?>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" 
        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav me-auto">
        <li class="nav-item">
          <a class="nav-link <?php if(isset($currentPage) && $currentPage=='home') echo 'active'; ?>" href="index.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php if(isset($currentPage) && $currentPage=='pemesanan') echo 'active'; ?>" href="pemesanan.php">Pemesanan</a>
        </li>
        <?php if($role == 'user'): ?>
        <li class="nav-item">
          <a class="nav-link <?php if(isset($currentPage) && $currentPage=='dashboard_user') echo 'active'; ?>" href="dashboard_user.php">Lihat Pesanan</a>
        </li>
        <?php endif; ?>
        <li class="nav-item">
          <a class="nav-link <?php if(isset($currentPage) && $currentPage=='tentang') echo 'active'; ?>" href="about.php">Tentang</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php if(isset($currentPage) && $currentPage=='kontak') echo 'active'; ?>" href="contact.php">Kontak</a>
        </li>
      </ul>

      <?php if($role != ''): ?>
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link btn btn-outline-light ms-2" href="logout.php">Logout</a>
        </li>
      </ul>
      <?php else: ?>
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link btn btn-outline-light ms-2" href="login.php">Login</a>
        </li>
      </ul>
      <?php endif; ?>
    </div>
  </div>
</nav>

<style>
.navbar-nav .nav-link.active {
    font-weight: 600;
    color: #ffc107 !important; /* highlight active menu */
}
</style>
