<?php
session_start();
include 'koneksi.php';

if(!isset($_SESSION['username']) || $_SESSION['role'] != 'admin'){
    header("Location: login.php");
    exit;
}

$id = $_GET['id'] ?? null;
if(!$id){
    header("Location: admin.php");
    exit;
}

// Ambil data kontak
$data = mysqli_query($conn, "SELECT * FROM kontak WHERE id='$id'");
$row = mysqli_fetch_assoc($data);

if(isset($_POST['kirim'])){
    $balasan = $_POST['balasan'];
    mysqli_query($conn, "UPDATE kontak SET balasan='$balasan' WHERE id='$id'");
    header("Location: admin.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Balas Pesan</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2>Balas Pesan dari: <?php echo $row['nama']; ?></h2>
    <p>Email: <?php echo $row['email']; ?></p>
    <p>Pesan: <?php echo $row['pesan']; ?></p>

    <form method="POST">
        <div class="mb-3">
            <label>Balasan</label>
            <textarea name="balasan" class="form-control" rows="4"><?php echo $row['balasan'] ?? ''; ?></textarea>
        </div>
        <button type="submit" name="kirim" class="btn btn-primary">Kirim Balasan</button>
        <a href="admin.php" class="btn btn-secondary">Kembali</a>
    </form>
</div>
</body>
</html>
